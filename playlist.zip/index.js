function _0x3125() {
  const _0x4db7ba = [
    "poru",
    "254630ZNxPHY",
    "Green",
    "color-console",
    "./handlers/anticrash",
    "deferReply",
    "Player\x20is\x20not\x20paused\x20!",
    "scsearch",
    "33340YUyLnG",
    "user",
    "2055441nPLkzH",
    "length",
    "Joined\x20",
    "224LnbPLH",
    "guild",
    "isConnected",
    "queue",
    "discord-api-types/v10",
    "disconnect",
    "init",
    "Stops\x20the\x20music",
    "Disconnected\x20the\x20player!",
    "member",
    "\x20has\x20been\x20loaded\x20with\x20",
    "commandName",
    "add",
    "setColor",
    "isPaused",
    "toString",
    "discord.js",
    "voice",
    "channel",
    "tracks",
    "ytsearch",
    "name",
    "floor",
    "Started!",
    "play",
    "Guilds",
    "13689837Phjhnt",
    "reply",
    "[INFO]\x20Client\x20has\x20been\x20started!",
    "Please\x20connect\x20with\x20voice\x20channel\x20",
    "title",
    "cyan",
    "Start\x20the\x20music",
    "random",
    "host",
    "loadType",
    "put",
    "34907TIMwIf",
    "124873txFcjB",
    "LOAD_FAILED",
    "583CEtfEj",
    "createConnection",
    "Join\x20your\x20Voicechannel",
    "Connected\x20to:\x20",
    "stop",
    "channelId",
    "PLAYLIST_LOADED",
    "Pauses\x20the\x20music",
    "resume",
    "applicationGuildCommands",
    "get",
    "./config.json",
    "cache",
    "channels",
    "requester",
    "\x0a-\x20",
    "then",
    "guildid",
    "channelid",
    "Paused\x20the\x20player",
    "Disconnected\x20the\x20player\x20!",
    "login",
    "interactionCreate",
    "54SFkNzu",
    "Red",
    "415kwhGSK",
    "MessageContent",
    "pause",
    "NO_MATCHES",
    "password",
    "Failed\x20to\x20load\x20track.",
    "Paused\x20has\x20been\x20successfully\x20unpaused!",
    "info",
    "port",
    "Player\x20is\x20already\x20paused",
    "join",
    "players",
    "1936890vgkOob",
    "setDescription",
    "No\x20source\x20found!",
    "editReply",
    "setToken",
    "destroy",
    "guildId",
    "Player\x20is\x20not\x20ready\x20!",
    "log",
    "token",
    "Aqua",
    "applicationid",
  ];
  _0x3125 = function () {
    return _0x4db7ba;
  };
  return _0x3125();
}
const _0x2ff45c = _0x17da;
(function (_0x14b154, _0x15ae3a) {
  const _0x5a9a38 = _0x17da,
    _0x4d6d61 = _0x14b154();
  while (!![]) {
    try {
      const _0x364a56 =
        (parseInt(_0x5a9a38(0xe2)) / 0x1) * (parseInt(_0x5a9a38(0xfc)) / 0x2) +
        -parseInt(_0x5a9a38(0xba)) / 0x3 +
        (-parseInt(_0x5a9a38(0xb8)) / 0x4) *
          (-parseInt(_0x5a9a38(0xfe)) / 0x5) +
        parseInt(_0x5a9a38(0xa4)) / 0x6 +
        (-parseInt(_0x5a9a38(0xe3)) / 0x7) * (parseInt(_0x5a9a38(0xbd)) / 0x8) +
        parseInt(_0x5a9a38(0xd7)) / 0x9 +
        (parseInt(_0x5a9a38(0xb1)) / 0xa) * (-parseInt(_0x5a9a38(0xe5)) / 0xb);
      if (_0x364a56 === _0x15ae3a) break;
      else _0x4d6d61["push"](_0x4d6d61["shift"]());
    } catch (_0x244902) {
      _0x4d6d61["push"](_0x4d6d61["shift"]());
    }
  }
})(_0x3125, 0xe6798);
const { Client, ChannelType, EmbedBuilder } = require("discord.js"),
  c = require(_0x2ff45c(0xf0)),
  { Poru } = require("poru"),
  collorConsole = require(_0x2ff45c(0xb3)),
  { REST } = require("@discordjs/rest"),
  { Routes } = require(_0x2ff45c(0xc1)),
  ms = require("ms"),
  dir = require("./playlist.json"),
  fs = require("fs"),
  { handlerErrors } = require(_0x2ff45c(0xb4)),
  colorConsole = require(_0x2ff45c(0xb3)),
  client = new Client({
    intents: [
      _0x2ff45c(0xd6),
      "GuildMessages",
      _0x2ff45c(0x99),
      "GuildVoiceStates",
    ],
  }),
  nodes = [
    {
      name: c["name"],
      host: c[_0x2ff45c(0xdf)],
      port: c[_0x2ff45c(0xa0)],
      password: c[_0x2ff45c(0x9c)],
    },
  ],
  PoruOptions = { library: _0x2ff45c(0xcd), defaultPlatform: _0x2ff45c(0xd1) };
function _0x17da(_0x418184, _0xf4eaf5) {
  const _0x3125d8 = _0x3125();
  return (
    (_0x17da = function (_0x17dadd, _0xecbf50) {
      _0x17dadd = _0x17dadd - 0x99;
      let _0x160527 = _0x3125d8[_0x17dadd];
      return _0x160527;
    }),
    _0x17da(_0x418184, _0xf4eaf5)
  );
}
(client[_0x2ff45c(0xb0)] = new Poru(client, nodes, PoruOptions)),
  client[_0x2ff45c(0xfa)](c["token"])["then"](() => {
    const _0x5474f0 = _0x2ff45c;
    client[_0x5474f0(0xb0)][_0x5474f0(0xc3)](client),
      handlerErrors(client)[_0x5474f0(0xf5)](() => {
        const _0x2c8830 = _0x5474f0;
        colorConsole[_0x2c8830(0xdc)](_0x2c8830(0xd9));
      });
  });
const rest = new REST({ version: "10" })[_0x2ff45c(0xa8)](c[_0x2ff45c(0xad)]);
async function main() {
  const _0x5ecbd9 = _0x2ff45c,
    _0x35949e = [
      { name: _0x5ecbd9(0xe9), description: _0x5ecbd9(0xc4) },
      { name: _0x5ecbd9(0xd5), description: _0x5ecbd9(0xdd) },
      { name: _0x5ecbd9(0xa2), description: _0x5ecbd9(0xe7) },
      {
        name: _0x5ecbd9(0xc2),
        description:
          "Disconnect\x20the\x20bot\x20(Only\x20works\x20when\x20music\x20is\x20stopped)",
      },
      { name: _0x5ecbd9(0x9a), description: _0x5ecbd9(0xec) },
      { name: _0x5ecbd9(0xed), description: "Resumes\x20the\x20music" },
    ];
  try {
    console[_0x5ecbd9(0xac)](
      "Started\x20refreshing\x20application\x20(/)\x20commands."
    ),
      await rest[_0x5ecbd9(0xe1)](
        Routes[_0x5ecbd9(0xee)](c[_0x5ecbd9(0xaf)], c[_0x5ecbd9(0xf6)]),
        { body: _0x35949e }
      );
  } catch (_0x2a3193) {
    console[_0x5ecbd9(0xac)](_0x2a3193);
  }
}
main(),
  client["on"](_0x2ff45c(0xfb), async (_0xae63f5) => {
    const _0x5a9f50 = _0x2ff45c,
      _0x211bd4 = client[_0x5a9f50(0xf2)][_0x5a9f50(0xf1)]["get"](
        c[_0x5a9f50(0xf7)]
      );
    _0xae63f5[_0x5a9f50(0xc8)] === "play" &&
      playerStart(_0xae63f5)["catch"]((_0x26b7cf) => {
        console["log"](_0x26b7cf);
      });
    if (_0xae63f5[_0x5a9f50(0xc8)] === _0x5a9f50(0xe9)) {
      const _0x21c8e5 = client[_0x5a9f50(0xb0)]["players"][_0x5a9f50(0xef)](
          _0xae63f5[_0x5a9f50(0xaa)]
        ),
        _0x8cc556 = new EmbedBuilder()
          [_0x5a9f50(0xca)](_0x5a9f50(0xae))
          [_0x5a9f50(0xa5)]("Stopped\x20the\x20player!");
      if (!_0x21c8e5)
        return _0xae63f5[_0x5a9f50(0xd8)]({
          embeds: [
            _0x8cc556[_0x5a9f50(0xa5)](_0x5a9f50(0xab))["setColor"](
              _0x5a9f50(0xfd)
            ),
          ],
        });
      return (
        _0x21c8e5[_0x5a9f50(0xa9)](),
        _0xae63f5[_0x5a9f50(0xd8)]({ embeds: [_0x8cc556] })
      );
    }
    if (_0xae63f5[_0x5a9f50(0xc8)] === "join") {
      if (!_0xae63f5["member"]["voice"]["channel"])
        return _0xae63f5[_0x5a9f50(0xa7)]({
          content: _0x5a9f50(0xda),
          ephemeral: !![],
        });
      client[_0x5a9f50(0xb0)][_0x5a9f50(0xe6)]({
        guildId: _0xae63f5[_0x5a9f50(0xbe)]["id"],
        voiceChannel:
          _0xae63f5[_0x5a9f50(0xc6)][_0x5a9f50(0xce)]["channel"]["id"],
        textChannel: _0xae63f5[_0x5a9f50(0xcf)]["id"],
        deaf: !![],
      });
      const _0x241070 = new EmbedBuilder()
        [_0x5a9f50(0xca)](_0x5a9f50(0xae))
        ["setDescription"](
          _0x5a9f50(0xbc) +
            _0xae63f5[_0x5a9f50(0xc6)][_0x5a9f50(0xce)][_0x5a9f50(0xcf)][
              _0x5a9f50(0xcc)
            ]()
        );
      return _0xae63f5[_0x5a9f50(0xd8)]({ embeds: [_0x241070] });
    }
    if (_0xae63f5[_0x5a9f50(0xc8)] === _0x5a9f50(0xc2)) {
      const _0x5303e9 = client["poru"][_0x5a9f50(0xa3)][_0x5a9f50(0xef)](
          _0xae63f5[_0x5a9f50(0xaa)]
        ),
        _0x15c5ed = new EmbedBuilder()
          ["setColor"](_0x5a9f50(0xae))
          ["setDescription"](_0x5a9f50(0xc5));
      if (!_0x5303e9)
        return _0xae63f5["reply"]({
          embeds: [
            _0x15c5ed["setDescription"](_0x5a9f50(0xf9))[_0x5a9f50(0xca)](
              _0x5a9f50(0xfd)
            ),
          ],
        });
      return (
        _0x5303e9[_0x5a9f50(0xa9)](),
        _0xae63f5[_0x5a9f50(0xd8)]({ embeds: [_0x15c5ed] })
      );
    }
    if (_0xae63f5[_0x5a9f50(0xc8)] === "pause") {
      const _0x5a98c5 = client[_0x5a9f50(0xb0)][_0x5a9f50(0xa3)][
        _0x5a9f50(0xef)
      ](_0xae63f5[_0x5a9f50(0xbe)]["id"]);
      if (_0x5a98c5[_0x5a9f50(0xcb)]) {
        const _0xa1400c = new EmbedBuilder()
          ["setColor"](_0x5a9f50(0xfd))
          [_0x5a9f50(0xa5)](_0x5a9f50(0xa1));
        return _0xae63f5[_0x5a9f50(0xd8)]({ embeds: [_0xa1400c] });
      }
      _0x5a98c5["pause"](!![]);
      const _0x1a97a7 = new EmbedBuilder()
        [_0x5a9f50(0xca)](_0x5a9f50(0xb2))
        ["setDescription"](_0x5a9f50(0xf8));
      return _0xae63f5[_0x5a9f50(0xd8)]({ embeds: [_0x1a97a7] });
    }
    if (_0xae63f5["commandName"] === _0x5a9f50(0xed)) {
      const _0x24f21f = client[_0x5a9f50(0xb0)]["players"]["get"](
        _0xae63f5[_0x5a9f50(0xbe)]["id"]
      );
      if (!_0x24f21f[_0x5a9f50(0xcb)]) {
        const _0x2722c5 = new EmbedBuilder()
          [_0x5a9f50(0xca)](_0x5a9f50(0xfd))
          [_0x5a9f50(0xa5)](_0x5a9f50(0xb6));
        return _0xae63f5["reply"]({ embeds: [_0x2722c5] });
      }
      _0x24f21f[_0x5a9f50(0x9a)](![]);
      const _0x5556f9 = new EmbedBuilder()
        [_0x5a9f50(0xca)](_0x5a9f50(0xb2))
        [_0x5a9f50(0xa5)](_0x5a9f50(0x9e));
      return _0xae63f5[_0x5a9f50(0xd8)]({ embeds: [_0x5556f9] });
    }
  });
async function playerStart(_0x533037) {
  const _0x1b9558 = _0x2ff45c;
  await _0x533037[_0x1b9558(0xb5)]();
  const _0x8f79ee = Math[_0x1b9558(0xd3)](
      Math[_0x1b9558(0xde)]() * dir[_0x1b9558(0xbb)]
    ),
    _0x2eb53e = dir[_0x8f79ee];
  if (!_0x533037[_0x1b9558(0xc6)][_0x1b9558(0xce)][_0x1b9558(0xcf)])
    return _0x533037["editReply"]({
      content: _0x1b9558(0xda),
      ephemeral: !![],
    });
  const _0x4b8237 = _0x2eb53e,
    _0x5ddc38 = await client[_0x1b9558(0xb0)]["resolve"]({
      query: _0x4b8237,
      source: _0x1b9558(0xb7),
      requester: _0x533037[_0x1b9558(0xc6)],
    });
  if (_0x5ddc38[_0x1b9558(0xe0)] === _0x1b9558(0xe4))
    return _0x533037[_0x1b9558(0xd8)](_0x1b9558(0x9d));
  else {
    if (_0x5ddc38[_0x1b9558(0xe0)] === _0x1b9558(0x9b))
      return _0x533037[_0x1b9558(0xa7)](_0x1b9558(0xa6));
  }
  const _0x6adc01 = client[_0x1b9558(0xb0)]["createConnection"]({
    guildId: _0x533037[_0x1b9558(0xbe)]["id"],
    voiceChannel: _0x533037[_0x1b9558(0xc6)]["voice"][_0x1b9558(0xea)],
    textChannel: _0x533037[_0x1b9558(0xcf)]["id"],
    deaf: !![],
  });
  if (_0x5ddc38[_0x1b9558(0xe0)] === _0x1b9558(0xeb)) {
    for (const _0x3061e2 of _0x5ddc38[_0x1b9558(0xd0)]) {
      (_0x3061e2[_0x1b9558(0x9f)][_0x1b9558(0xf3)] =
        _0x533037[_0x1b9558(0xb9)]),
        _0x6adc01[_0x1b9558(0xc0)][_0x1b9558(0xc9)](_0x3061e2);
    }
    _0x533037["editReply"](
      _0x5ddc38["playlistInfo"][_0x1b9558(0xd2)] +
        _0x1b9558(0xc7) +
        _0x5ddc38["tracks"]["length"]
    );
  } else {
    const _0xcc0062 = _0x5ddc38[_0x1b9558(0xd0)][0x0];
    (_0xcc0062["info"][_0x1b9558(0xf3)] = _0x533037[_0x1b9558(0xb9)]),
      _0x6adc01[_0x1b9558(0xc0)][_0x1b9558(0xc9)](_0xcc0062),
      _0x533037["editReply"]({
        embeds: [
          {
            title: _0x1b9558(0xd4),
            description:
              _0x1b9558(0xe8) +
              _0x533037[_0x1b9558(0xc6)]["voice"][_0x1b9558(0xcf)] +
              _0x1b9558(0xf4) +
              _0xcc0062[_0x1b9558(0x9f)][_0x1b9558(0xdb)],
            color: 0xec8eed,
          },
        ],
      });
  }
  if (!_0x6adc01["isPlaying"] && _0x6adc01[_0x1b9558(0xbf)])
    _0x6adc01[_0x1b9558(0xd5)]();
}
