const { Client, ChannelType, EmbedBuilder } = require("discord.js");
const c = require("./config.json");
const { Poru } = require("poru");
const collorConsole = require("color-console");
const { REST } = require("@discordjs/rest");
const { Routes } = require("discord-api-types/v10");

const ms = require("ms");

const dir = require("./playlist.json");

const fs = require("fs");

const { handlerErrors } = require("./handlers/anticrash");
const colorConsole = require("color-console");

const client = new Client({
  intents: ["Guilds", "GuildMessages", "MessageContent", "GuildVoiceStates"],
});

const nodes = [
  {
    name: c.name,
    host: c.host,
    port: c.port,
    password: c.password
  },
];
const PoruOptions = {
  library: "discord.js",
  defaultPlatform: "ytsearch",
};

client.poru = new Poru(client, nodes, PoruOptions);

client.login(c.token).then(() => {
  client.poru.init(client);
  handlerErrors(client).then(() => {
    colorConsole.cyan(`[INFO] Client has been started!`);
  });
});

const rest = new REST({ version: "10" }).setToken(c.token);

async function main() {
  const commands = [
    {
      name: "stop",
      description: "Stops the music",
    },
    {
      name: "play",
      description: "Start the music",
    },
    {
      name: "join",
      description: "Join your Voicechannel",
    },
    {
      name: "disconnect",
      description: "Disconnect the bot (Only works when music is stopped)",
    },
    {
      name: "pause",
      description: "Pauses the music",
    },
    {
      name: "resume",
      description: "Resumes the music",
    },
  ];
  try {
    console.log("Started refreshing application (/) commands.");
    await rest.put(
      Routes.applicationGuildCommands(c.applicationid, c.guildid),
      {
        body: commands,
      }
    );
  } catch (err) {
    console.log(err);
  }
}

main();

client.on("interactionCreate", async (interaction) => {
  const voice = client.channels.cache.get(c.channelid);
  if (interaction.commandName === "play") {
    playerStart(interaction).catch(e => { console.log(e) });
  }

  if (interaction.commandName === "stop") {
    const player = client.poru.players.get(interaction.guildId);

    const embed = new EmbedBuilder()
      .setColor("Aqua")
      .setDescription("Stopped the player!");

    if (!player) {
      return interaction.reply({
        embeds: [embed.setDescription(`Player is not ready !`).setColor("Red")],
      });
    }

    player.destroy();

    return interaction.reply({
      embeds: [embed],
    });
  }

  if (interaction.commandName === "join") {
    if (!interaction.member.voice.channel)
      return interaction.editReply({
        content: `Please connect with voice channel `,
        ephemeral: true,
      });

    client.poru.createConnection({
      guildId: interaction.guild.id,
      voiceChannel: interaction.member.voice.channel.id,
      textChannel: interaction.channel.id,
      deaf: true,
    });

    const embed = new EmbedBuilder()
      .setColor("Aqua")
      .setDescription(`Joined ${interaction.member.voice.channel.toString()}`);

    return interaction.reply({
      embeds: [embed],
    });
  }

  if (interaction.commandName === "disconnect") {
    const player = client.poru.players.get(interaction.guildId);

    const embed = new EmbedBuilder()
      .setColor("Aqua")
      .setDescription("Disconnected the player!");

    if (!player) {
      return interaction.reply({
        embeds: [
          embed.setDescription(`Disconnected the player !`).setColor("Red"),
        ],
      });
    }
    player.destroy();
    return interaction.reply({
      embeds: [embed],
    });
  }

  if(interaction.commandName === "pause") {
    const player = client.poru.players.get(interaction.guild.id);

    if (player.isPaused) {
      const embed = new EmbedBuilder()
        .setColor('Red')
        .setDescription('Player is already paused');

      return interaction.reply({
        embeds: [embed],
      });
    }

    player.pause(true);

    const embed = new EmbedBuilder()
      .setColor('Green')
      .setDescription('Paused the player');

    return interaction.reply({
      embeds: [embed],
    });
  }

  if(interaction.commandName === "resume") {
    const player = client.poru.players.get(interaction.guild.id);

    if (!player.isPaused) {
      const embed = new EmbedBuilder()
        .setColor('Red')
        .setDescription('Player is not paused !');

      return interaction.reply({
        embeds: [embed],
      });
    }

    player.pause(false);

    const embed = new EmbedBuilder()
      .setColor('Green')
      .setDescription('Paused has been successfully unpaused!');

    return interaction.reply({
      embeds: [embed],
    });
  }
});

async function playerStart(interaction) {
  await interaction.deferReply();
  const number = Math.floor(Math.random() * dir.length);
  const search = dir[number];

  if (!interaction.member.voice.channel)
    return interaction.editReply({
      content: `Please connect with voice channel `,
      ephemeral: true,
    });

  const track = search;

  const res = await client.poru.resolve({
    query: track,
    source: "scsearch",
    requester: interaction.member,
  });

  if (res.loadType === "LOAD_FAILED") {
    return interaction.reply("Failed to load track.");
  } else if (res.loadType === "NO_MATCHES") {
    return interaction.editReply("No source found!");
  }

  //create connection with discord voice channnel
  const player = client.poru.createConnection({
    guildId: interaction.guild.id,
    voiceChannel: interaction.member.voice.channelId,
    textChannel: interaction.channel.id,
    deaf: true,
  });

  if (res.loadType === "PLAYLIST_LOADED") {
    for (const track of res.tracks) {
      track.info.requester = interaction.user;
      player.queue.add(track);
    }

    interaction.editReply(
      `${res.playlistInfo.name} has been loaded with ${res.tracks.length}`
    );
  } else {
    const track = res.tracks[0];
    track.info.requester = interaction.user;
    player.queue.add(track);
    interaction.editReply({
      embeds: [
        {
          title: "Started!",
          description: `Connected to: ${interaction.member.voice.channel}\n- ${track.info.title}`,
          color: 15503085,
        },
      ],
    });
  }

  if (!player.isPlaying && player.isConnected) player.play();
}
