
const collorConsole = require("color-console")

async function handlerErrors(client) {
    process.on('unhandledRejection', async (err) => {
        console.log(err)
    })
    
    process.on('uncaughtExceptionMonitor', async (err) => {
        return;
    })
    
    process.on('uncaughtException', async (err) => {
        console.log(err)
    })    

    collorConsole.cyan(`[INFO] AntiCrash Manager: Connected !`)
}

module.exports = { handlerErrors }